<?php if (!defined('AFISYNTAX')) die('Access Denied'); error_reporting(0); ?>
    <div class="container-fluid">
    	<?php breadcrumb($base_url,$title); message($url_data);?>
    	<div class="card modul">
    		<?php titleContent($icon,$judul); ?>
  			<div class="card-body">
            <?php tab_1();?>
            <div class="tab-content" id="myTabContent">
				<div class="tab-pane fade show active" id="tabeldata" role="tabpanel" >
					<div class="card">
						<div class="card-body table-responsive">
                         <script type="text/javascript">							 	
                                var dTable;
                                $(document).ready(function() {
                                dTable = $('#afi').DataTable( {
                                "bProcessing": true,
                                "bServerSide": true,
                                "bJQueryUI": false,
                                "responsive": true,
                                "sAjaxSource": "<?php echo $base_url.'/data/'.md5($kunci.$url_page);?>", 
                                "sServerMethod": "POST",
                                "columnDefs": [
                                    { "orderable": true, "targets": 0, "searchable": false },
                                    { "orderable": true, "targets": 1, "searchable": true },
									{ "orderable": true, "targets": 2, "searchable": true },
                                    { "orderable": true, "targets": 3, "searchable": true },
									{ "width": "3%", "targets": 9}]
								
                                });
								});
                            </script>
                            <table id="afi" class="table table-bordered table-striped" style="width:100%; font-size:12px">
                                <thead class="text-center">
                                    <tr>
                                    	<th>No.</th>
                                        <th>Progdi</th>
                                        <th>NIK</th>
                                        <th>NIM</th>
                                    	<th>Nama Mahasiswa</th>
                                        <th>Jekel</th>
                                        <th>TTL</th>
                                        <th>Alamat</th>
                                        <th>No. Telp</th>
                                        <th>Status</th>
                                        <th>Aksi</th                                                                            
                                    ></tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>  
                    </div>                                
				</div>
				<div class="tab-pane fade" id="insertdata" role="tabpanel" >
              		<div class="card row">
        				<div class="card-body col-md-6 offset-md-3">        
						<?php 
                            startForm('row','post',$base_url.'/aksi/'.md5($kunci.$url_page));
							$tgl	= array();
							$mulai	= date('Y') - 15;
							while($mulai <= date('Y')){
								$tgl[]	= $mulai++;
							};
                        ?>
                        	<div class="form-group col-sm-12">
                			<?php  selectBase('Fakultas','fakultas','fakultas','kodefakultas','namafakultas',NULL,$_user,$_name,$_pass,$host); ?>
                            </div> 
                            <div class="form-group col-sm-12" id="prog">
                            </div>
                            <div class="form-group col-sm-12">
                			<?php selectTexted('Tahun Pendaftaran','tahun',$tgl,NULL); ?>
                            </div>
                            <div class="form-group col-sm-12">
                			<?php inputText('NIK','nik'); ?>
                            </div>  
                            <div class="form-group col-sm-12">
                			<?php inputText('Nama Mahasiswa','namamhs'); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php  selectBase('Jenis Kelamin','jekel','jekel','kodejekel','namajekel',NULL,$_user,$_name,$_pass,$host); ?>
                            </div>
                             <div class="form-group col-sm-12">
                			<?php  selectBase('Agama','agama','agama','kodeagama','namaagama',NULL,$_user,$_name,$_pass,$host); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('Tempat Lahir','tempatlahirmhs'); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('Tanggal Lahir (Format: Tahun-Bulan-Tanggal)','tanggallahirmhs'); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php textareaText('Alamat Lengkap','alamatmhs'); ?>
                            </div>
                            <div class="form-group col-sm-12">
                			<?php inputText('Kota Mahasiswa','kotamhs'); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('No. Telp/HP','telpmhs'); ?>
                            </div> 
                            <?php SaveText(); ?>
                            <?php endForm();?>
						</div>
					</div>
				</div>
			</div>
            </div>
		</div>
	</div>