<?php if (!defined('AFISYNTAX')) die('Access Denied'); error_reporting(0); ?>
    <div class="container-fluid">
    	<?php breadcrumb($base_url,$title); message($url_data);?>
    	<div class="card modul">
    		<?php titleContent($icon,$judul); ?>
  			<div class="card-body">
            <?php tab_1();?>
            <div class="tab-content" id="myTabContent">
				<div class="card tab-pane fade show active" id="tabeldata" role="tabpanel" >
					<div class="card">
						<div class="card-body table-responsive">
                         <script type="text/javascript">							 	
                                var dTable;
                                $(document).ready(function() {
                                dTable = $('#afi').DataTable( {
                                "bProcessing": true,
                                "bServerSide": true,
                                "bJQueryUI": false,
                                "responsive": true,
                                "sAjaxSource": "<?php echo $base_url.'/data/'.md5($kunci.$url_page);?>", 
                                "sServerMethod": "POST",
                                "columnDefs": [
                                    { "orderable": true, "targets": 0, "searchable": false },
                                    { "orderable": true, "targets": 1, "searchable": true },
									{ "orderable": true, "targets": 2, "searchable": true },
                                    { "orderable": true, "targets": 3, "searchable": true },
									{ "width": "3%", "targets": 10}]
								
                                });
								});
                            </script>
                            <table id="afi" class="table table-bordered table-striped" style="width:100%; font-size:12px">
                                <thead class="text-center">
                                    <tr>
                                    	<th>No.</th>
                                        <th>NIK</th>                                        
                                    	<th>Nama Karyawan</th>
                                        <th>JeKel</th>
                                        <th>Agama</th>
                                        <th>TTL</th>
                                        <th>Alamat</th>
                                        <th>No. Telp</th>
                                        <th>Tahun Masuk</th>
                                        <th>Status</th>
                                        <th>Aksi</th                                                                            
                                    ></tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>  
                    </div>                                
				</div>
				<div class="tab-pane fade" id="insertdata" role="tabpanel" >
              		<div class="card row">
        				<div class="card-body col-md-12">        
						<?php 
                            startForm('row','post',$base_url.'/aksi/'.md5($kunci.$url_page));
							$tgl	= array();
							$mulai	= date('Y') - 40;
							while($mulai <= date('Y')){
								$tgl[]	= $mulai++;
							};
                        ?>
                            <div class="form-group col-sm-6">
                			<?php selectTexted('Tahun Masuk','tahunpgw',$tgl,NULL); ?>
                            </div> 
                            <div class="form-group col-sm-6">
                			<?php inputText('NIK','nik'); ?>
                            </div> 
                            <div class="form-group col-sm-6">
                			<?php inputText('Nama Karyawan','namapgw'); ?>
                            </div> 
                            <div class="form-group col-sm-6">
                			<?php  selectBase('Jenis Kelamin','jekel','jekel','kodejekel','namajekel',NULL,$_user,$_name,$_pass,$host); ?>
                            </div>
                            <div class="form-group col-sm-6">
                			<?php  selectBase('Agama','agama','agama','kodeagama','namaagama',NULL,$_user,$_name,$_pass,$host); ?>
                            </div> 
                            <div class="form-group col-sm-6">
                			<?php inputText('Tempat Lahir','tempatlahirpgw'); ?>
                            </div> 
                            <div class="form-group col-sm-6">
                			<?php inputText('Tanggal Lahir (Format: Tahun-Bulan-Tanggal)','tanggallahirpgw'); ?>
                            </div> 
                             <div class="form-group col-sm-6">
                			<?php inputText('No. Telp/HP','telppgw'); ?>
                            </div>
                            <div class="form-group col-sm-6">
                			<?php  selectBase('Status Karyawan','statuspgw','statuspgw','kodestatuspgw','namastatuspgw',NULL,$_user,$_name,$_pass,$host); ?>
                            </div> 
                            <div class="form-group col-sm-6">
                			<?php inputText('Kota','kotapgw'); ?>
                            </div> 
                            <div class="form-group col-sm-6">
                			<?php textareaText('Alamat Lengkap','alamatpgw'); ?>
                            </div>
                            <?php SaveText(); ?>
                            <?php endForm();?>
						</div>
					</div>
				</div>
			</div>
            </div>
		</div>
	</div>