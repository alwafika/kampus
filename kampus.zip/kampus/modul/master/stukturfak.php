<?php if (!defined('AFISYNTAX')) die('Access Denied'); error_reporting(0); ?>
    <div class="container">
    	<?php breadcrumb($base_url,$title); message($url_data);?>
    	<div class="card modul">
    		<?php titleContent($icon,$judul); ?>
  			<div class="card-body">
            <?php tab_1();?>
            <div class="tab-content" id="myTabContent">
				<div class="tab-pane fade show active" id="tabeldata" role="tabpanel" >
					<div class="card">
						<div class="card-body table-responsive">
                         <script type="text/javascript">							 	
                                var dTable;
                                $(document).ready(function() {
                                dTable = $('#afi').DataTable( {
                                "bProcessing": true,
                                "bServerSide": true,
                                "bJQueryUI": false,
                                "responsive": true,
                                "sAjaxSource": "<?php echo $base_url.'/data/'.md5($kunci.$url_page);?>", 
                                "sServerMethod": "POST",
                                "columnDefs": [
                                    { "orderable": true, "targets": 0, "searchable": false },
                                    { "orderable": true, "targets": 1, "searchable": true },
									{ "orderable": true, "targets": 2, "searchable": true },
                                    { "orderable": true, "targets": 3, "searchable": false },
									{ "width": "3%", "targets": 4}]
								
                                });
								});
                            </script>
                            <table id="afi" class="table table-bordered table-striped" style="width:100%; font-size:13px">
                                <thead class="text-center">
                                    <tr>
                                    	<th>No.</th>
                                        <th>Fakultas</th>
                                    	<th>Nama Jabatan</th>
                                    	<th>Tugas dan Fungsi</th>
                                        <th>Aksi</th                                                                            
                                    ></tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>  
                    </div>                                
				</div>
				<div class="tab-pane fade" id="insertdata" role="tabpanel" >
              		<div class="card row">
        				<div class="card-body col-md-6 offset-md-3">                          	  
						<?php startForm('row','post',$base_url.'/aksi/'.md5($kunci.$url_page));?>
                        	<div class="form-group col-sm-12">    
                        <?php selectBase('Fakultas','fakultas','fakultas','kodefakultas','namafakultas',NULL,$_user,$_name,$_pass,$host);?>
                        	</div>
                            <div class="form-group col-sm-12">
                			<?php inputText('Nama Jabatan','namastuktur'); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php textareaText('Tugas dan Fungsi','tugas'); ?>
                            </div> 
                            <?php hiddenText('lembaga','2'); hiddenText('link',$url_page); SaveText(); ?>
                            <?php endForm();?>
						</div>
					</div>
				</div>
			</div>
            </div>
		</div>
	</div>