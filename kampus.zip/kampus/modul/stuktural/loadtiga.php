<?php if (!defined('AFISYNTAX')) die('Access Denied'); ?>
<?php heading($base_url);?>
<body>
<?php require('themes/topbar.php');?>
<main id="main">
<?php require('modul/stuktural/'.$url_page.'.php');?>
</main>
<?php require('themes/footer.php');?>
<script src="<?php  echo $base_url.'/validasi/master/'.$url_page;?>.js" type="text/javascript"></script>
<div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"></div>
<script type="text/javascript">
		$(document).on("click", "#edit", function () {
			var edit =  $(this).data("id");
			var afi	 = "<?php echo md5($kunci.'Edit');?>";
			$.ajax({
				url: "<?php echo $base_url.'/'.md5('modal').'/'.md5($kunci.$url_page);?>",
				type: "POST",
				data: "&AFI="+afi+"&edit="+edit,
				cache: false,
				success: function(data){
					$("#myModal").empty();			
					$("#myModal").html(data);			
				}
			});
		 });
		 $(document).on("click", "#delete", function () {
			var delet =  $(this).data("id");
			var afi	 = "<?php echo md5($kunci.'Delete');?>";
			$.ajax({
				url: "<?php echo $base_url.'/'.md5('modal').'/'.md5($kunci.$url_page);?>",
				type: "POST",
				data: "&AFI="+afi+"&delete="+delet,
				cache: false,
				success: function(data){
					$("#myModal").empty();			
					$("#myModal").html(data);			
				}
			});
		 });
		  $(document).on("change", "#fakultas", function () {
			var detail =  $("#fakultas").val();
			var afi	 = "<?php echo md5($kunci.'PilihProg');?>";
			$.ajax({
				url: "<?php echo $base_url.'/'.md5('modal').'/'.md5($kunci.$url_page);?>",
				type: "POST",
				data: "&AFI="+afi+"&detail="+detail,
				cache: false,
				success: function(data){
					$("#prog").empty();			
					$("#prog").html(data);			
				}
			});
		 });	
		  $(document).on("change", "#progdi", function () {
			var detail =  $("#progdi").val();
			var afi	 = "<?php echo md5($kunci.'PilihStuktur');?>";
			$.ajax({
				url: "<?php echo $base_url.'/'.md5('modal').'/'.md5($kunci.$url_page);?>",
				type: "POST",
				data: "&AFI="+afi+"&detail="+detail,
				cache: false,
				success: function(data){
					$("#stuk").empty();			
					$("#stuk").html(data);			
				}
			});
		 });	
<?php
$query = $record->ihik('pegawai','kodepgw,namapgw',NULL,'statuspgw="1"');
	switch(TRUE){
	case($query->num_rows > 0):
	while($row 	= $query->fetch_object()){
    		$pegawai[]	= $row->kodepgw.' || '.$row->namapgw;};
	break;
	default:
			$pegawai	= '';
	break;
	};
	
?>
		var pegawai 	= <?php echo json_encode($pegawai);?>;
		$("#pegawai").autocomplete({
         source: pegawai,
		 minLength:1
		});
</script>			
</body>
</html>
