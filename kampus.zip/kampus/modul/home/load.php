<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
heading($base_url);
?>
<body>
<?php require('themes/topbar.php');?>
<main id="main">
<div class="container">
<?php require('themes/menu.php');?>
</div>
</main>
<?php require('themes/footer.php');?>
</body>
</html>