 var anu = '/umkm';
 $('#header').load(window.location.origin+ anu +'/header');	
 $('#topbar').load(window.location.origin+ anu +'/topbar');
 $('#footer').load(window.location.origin+ anu +'/footer');
function change_url(val) {
window.location=val;
}
