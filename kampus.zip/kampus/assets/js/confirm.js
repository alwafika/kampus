  function ConfirmSetuju() {
	  var confm2 = window.confirm("Apakah anda yakin Menyetujui Proses ini?");
	  if(confm2 == true) {
		  return true;
	  } else {
		  return false;
	  }
  }

  function ConfirmDelete() {
	  var confm3 = window.confirm("Apakah anda yakin Menghapus data ini?");
	  if(confm3 == true) {
		  return true;
	  } else {
		  return false;
	  }
  }
  
  function ConfirmTolak() {
	  var confm2 = window.confirm("Apakah anda yakin Menolak data ini?");
	  if(confm2 == true) {
		  return true;
	  } else {
		  return false;
	  }
  }
  
 
   function lunas() {
	  var confm2 = window.confirm("Apakah pembayaran dibayar lunas ?");
	  if(confm2 == true) {
		  return true;
	  } else {
		  return false;
	  }
  }
   
  
    function ConfirmNoDelete() {
	  var confm2 = window.confirm("Mohon Maaf, data tidak boleh dihapus !");
	  if(confm2 == true) {
		  return true;
	  } else {
		  return false;
	  }
  } 
  
  
      function ConfirmMutasi() {
	  var confm2 = window.confirm("Apakah anda yakin Mutasi Pinjaman ?");
	  if(confm2 == true) {
		  return true;
	  } else {
		  return false;
	  }
  } 
 

  function ConfirmExcel() {
	  var confm3 = window.confirm("Apakah anda yakin Mengexport data ini?");
	  if(confm3 == true) {
		  return true;
	  } else {
		  return false;
	  }
  }
  
