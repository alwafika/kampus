<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
	$aColumns 		= array('tahunpgw', 'kodepgw', 'nik', 'namapgw', 'namajekel', 'namaagama', 'tempatlahirpgw', 'tanggallahirpgw', 'alamatpgw', 'kotapgw', 'telppgw', 'namastatuspgw'); 
	$sIndexColumn 	= 'kodepgw';
	$sTable 		= 'pegawai';
	$join			= ' JOIN jekel ON kodejekel=pegawai.jekel JOIN agama ON agama.kodeagama=pegawai.agama JOIN statuspgw ON statuspgw.kodestatuspgw=pegawai.statuspgw';
	$sLimit = "";
	switch(TRUE){
	case( isset( $input['iDisplayStart'] ) && $input['iDisplayLength'] != '-1' ):
		$sLimit = " LIMIT ".intval( $input['iDisplayStart'] ).", ".intval( $input['iDisplayLength'] );
		$no		= $input['iDisplayStart']+1;
	break;
	default:
		$no		= 1;
	break;
	};
	
	
	/**
		* Ordering
	*/
	$aOrderingRules = array();
	switch(TRUE){ 
	case( isset( $input['iSortCol_0'] ) ):
		$iSortingCols = intval( $input['iSortingCols'] );
		for ( $i=0 ; $i<$iSortingCols ; $i++ ) {
			switch(TRUE){ 
				case( $input[ 'bSortable_'.intval($input['iSortCol_'.$i]) ] == 'true' ):
						$aOrderingRules[] =
						"`".$aColumns[ intval( $input['iSortCol_'.$i] ) ]."` "
						.($input['sSortDir_'.$i]==='asc' ? 'asc' : 'desc');
				break;
			};
		};
	break;
	};
	
	switch(TRUE){ 
		case(!empty($aOrderingRules)):
			$sOrder = " ORDER BY namapgw ASC,  ".implode(", ", $aOrderingRules);
		break;
		default:
			$sOrder = " ORDER BY namapgw ASC ";
		break;
	};
	$iColumnCount = count($aColumns);
	
	switch(TRUE){ 
	case( isset($input['sSearch']) && $input['sSearch'] != "" ):
		$aFilteringRules = array();
		for ( $i=0 ; $i<$iColumnCount ; $i++ ) {
			switch(TRUE){ 
				case( isset($input['bSearchable_'.$i]) && $input['bSearchable_'.$i] == 'true' ):
					$aFilteringRules[] = "`".$aColumns[$i]."` LIKE '%".$record->real_escape_string( $input['sSearch'] )."%'";
				break;
			};
		};
		switch(TRUE){ 
			case(!empty($aFilteringRules)):
				$aFilteringRules = array('('.implode(" OR ", $aFilteringRules).')');
			break;
		};
	break;
	};
	for ( $i=0 ; $i<$iColumnCount ; $i++ ) {
		switch(TRUE){ 
			case( isset($input['bSearchable_'.$i]) && $input['bSearchable_'.$i] == 'true' && $input['sSearch_'.$i] != '' ):
				$aFilteringRules[] = "`".$aColumns[$i]."` LIKE '%".$record->real_escape_string($input['sSearch_'.$i])."%'";
			break;
		};
	};
	
	switch(TRUE){ 
		case(!empty($aFilteringRules)):
			$sWhere = " WHERE  ".implode(" AND ", $aFilteringRules);
		break;
		default:
			$sWhere = "  ";
		break;
	};
	$aQueryColumns = array();
	foreach ($aColumns as $col) {
		switch(TRUE){ 
			case($col != ' '):
			$aQueryColumns[] = $col;
			break;
		};
	};
	
	$sQuery = "
    SELECT SQL_CALC_FOUND_ROWS `".implode("`, `", $aQueryColumns)."`
    FROM `".$sTable."`".$join.$sWhere.$sOrder.$sLimit;
	
	$rResult = $record->query( $sQuery ) or die($record->error);
	
	// Data set length after filtering
	$sQuery = "SELECT FOUND_ROWS()";
	$rResultFilterTotal = $record->query( $sQuery ) or die($record->error);
	list($iFilteredTotal) = $rResultFilterTotal->fetch_row();
	
	// Total data set length
	$sQuery = "SELECT COUNT(`".$sIndexColumn."`) FROM `".$sTable."`";
	$rResultTotal = $record->query( $sQuery ) or die($record->error);
	list($iTotal) = $rResultTotal->fetch_row();
	
	
	/**
		* Output
	*/
	$output = array(
    "iTotalRecords"        => $iTotal,
    "iTotalDisplayRecords" => $iFilteredTotal,
    "aaData"               => array(),
	);
	// Looping Data
	while ( $aRow = $rResult->fetch_object()) {
		$row = array();
			
			$btn = '
			<div class="btn-group pull-right">
			<a class="btn btn-sm btn-outline-primary" id="edit" href="#" data-id="'.$aRow->kodepgw.'" data-toggle="modal" data-target="#myModal" title="Ubah Data"><span class="fa fa-edit"></span></a>
							<a class="btn btn-sm btn-outline-danger" id="delete" href="#" data-id="'.$aRow->kodepgw.'" data-toggle="modal" data-target="#myModal" title="Hapus Data"><span class="fa fa-trash"></span></a>
			</div>';
			
		for ( $i=0 ; $i<$iColumnCount ; $i++ ) {
			$columns	= $aColumns[$i];
			$row[] 		= $aRow->$columns;
		}
		$row = array($no++, $aRow->nik, $aRow->namapgw, $aRow->namajekel, $aRow->namaagama, $aRow->tempatlahirpgw.', '.$aRow->tanggallahirpgw, $aRow->alamatpgw.' '.$aRow->kotapgw, $aRow->telppgw,$aRow->tahunpgw, $aRow->namastatuspgw, $btn );
		$output['aaData'][] = $row;
	}
	
	echo json_encode( $output );
?>