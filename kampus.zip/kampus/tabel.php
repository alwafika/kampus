<?php
require_once('cpanel/setup.php');
require_once('cpanel/database.php');
$record			= new ngaceng;
$record->kukentukamu($_user,$_name,$_pass);
$colum	= $record->threesome('SHOW COLUMNS FROM pegawai');
	while($show	= $colum->fetch_object()){?>
    '<?php echo $show->Field;?>',<?php };?>
<?php
$colum	= $record->threesome('SHOW COLUMNS FROM pegawai');
	while($show	= $colum->fetch_object()){?>
    $aRow-><?php echo $show->Field;?>,<?php };?>