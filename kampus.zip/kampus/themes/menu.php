<?php if (!defined('AFISYNTAX')) die('Access Denied');
$query	= $record->ihik('menu','*',NULL,'target="0"');
while($data	= $query->fetch_object()){
	$submenu	= $record->ihik('menu','*',NULL,'target="'.$data->id.'"');
?>
    		<div class="card modul col-md-12 keren" data-depan="title" data-anu="BERANDA">
            	<div class="card-header">
            	<h6><i class="<?php echo $data->icon;?>"></i> <?php echo $data->menu;?></h6></div>
  				<div class="card-body">
            	 <ul class="nav nav-list"><?php  while($smenu = $submenu->fetch_object()){?>	
                 	<li class="nav-item">
                        <a id="menuku" href="<?php echo $base_url.'/'.$smenu->link;?>"><span class="menu-text"><i class="<?php echo $smenu->icon;?> menu-icon <?php echo $smenu->warna;?>"></i> <?php echo $smenu->menu;?></span></a>
                    </li><?php };?>                  
                 </ul>
                 </div>
      		</div>
<?php };?>
		