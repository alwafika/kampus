<?php if (!defined('AFISYNTAX')) die('Access Denied'); ?>
<footer id="footer">
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<h5>CONTACT INFO</h5>
				<address>
					<ul class="list-normal">
                    	<li><span class="fa fa-map-marker"></span> <?php echo $app->alamat; ?></li>
						<li><span class="fa fa-phone-square"></span> <?php  echo $app->telp; ?></li>
						<li><span class="fa fa-fax"></span> <?php echo $app->fax; ?></li>
						<li><span class="fa fa-envelope"></span> <?php  echo $app->email;?></li>
					</ul>
				</address>
			</div>
			<div class="col-sm-4 text-center">
				<p>&copy; Copyright <strong>PANJUL<span style="color:#ef9a9a;">.co.id</span></strong> All Rights Reserved<br>Designed by <a target="_blank" href="<?php echo $base_url;?>">PANJUL<span style="color:#ef9a9a;">.co.id</span></a></p>
			</div>
			<div class="col-sm-4 text-center">
				<img class="img-responsive" src="<?php echo $base_url;?>/images/logo/panjul.png" width="70" height="65"/>
			</div>
		</div>
	</div>
</footer>		
<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
<script src="<?php echo $base_url;?>/assets/js/jquery-2.1.4.min.js"></script>
<script src="<?php echo $base_url;?>/assets/js/jquery-ui.min.js"></script>      
<script src="<?php echo $base_url;?>/assets/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $base_url;?>/assets/js/afiatable.js"></script>	
<script src="<?php echo $base_url;?>/assets/js/jquery.validate.min.js"></script>
<script src="<?php echo $base_url;?>/assets/js/superfish.min.js"></script>
<script src="<?php echo $base_url;?>/assets/js/sticky.js"></script>
<script src="<?php echo $base_url;?>/assets/js/main.js"></script>
