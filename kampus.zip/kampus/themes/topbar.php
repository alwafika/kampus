<?php if (!defined('AFISYNTAX')) die('Access Denied'); ?>
<?php $query	= $record->ihik('license','*',NULL,'reg="'.$sesi['register'].'"'); $app	= $query->fetch_object();?>
<header id="header">
    <section id="topbar">
        <div class="container clearfix">
            <div id="logo">
                <h1 id="namaapp"><img src="<?php echo $base_url;?>/images/logo/panjul.png" style="width:27px; height:30px"/>
               <?php echo $app->nama;?><span style="font-size:0.5em; color: #ffff00;"> <?php echo $app->deskripsi;?></span></h1>
                </div>
            </div>
        </div>        
    </section> 
    <div class="container clearfix easy">
    	<div id="pilihanku" class="pull-left">
            	<span class="btn btn-sm sos"><i class="fa fa-user"></i> Online</span>
        </div>
        <div id="pilihan" class="pull-right">
			<?php /* <a class="btn btn-sm btn-outline-danger" href="<?php echo $base_url;?>/logout" data-rel="tooltip" title="Keluar Aplikasi"><i class="fa fa-power-off"></i></a> */ ?>
           	<a class="btn btn-sm btn-outline-light" href="<?php echo $base_url;?>" data-rel="tooltip" title="Beranda"><i class="fa fa-home"></i></a>
       	<?php $query = $record->ihik('menu','*',NULL,'target<>"0"','target ASC, id ASC'); ?>
       	<div class="btn-group dropright">
  				<a class="btn btn-sm btn-outline-light" href="#"  data-toggle="dropdown" data-rel="tooltip" title="Menu"> <i class="fa fa-bars"></i></a>
					<div class="dropdown-menu" id="dropdown-y">
 					<?php while($data = $query->fetch_object()){?>
	<a href="<?php echo $base_url.'/'.$data->link;?>" <?php if($url_page==$data->link || $url_page==$data->linkedit ||$url_page==$data->linkcetak ){$title=$data->menu; $judul=$data->title; $icon = $data->icon; ?> data-depan="title" class="dropdown-item disabled" data-anu="<?php echo strtoupper($data->title);?>" <?php }else{echo'class="dropdown-item"';}; ?>><?php echo $data->menu; ?></a>
					<?php }; ?>
</div>
				</div>     
         </div>
    </div> 
</header>
