// JavaScript Document By Afi
// AFI Validasi
$('#AFI-FORM').validate({
errorElement: 'div',
errorClass: 'help-block',
focusInvalid: false,
ignore: "",
rules: {
	kodefakultas: {
		required: true,
		number: true
	},
	namafakultas: {
		required: true
	}
},
messages: {
	kodefakultas: {
		required: "Inputan diatas masih kosong, Silahkan diisi!",
		number: "Format inputan berupa Angka!"
	},
	namafakultas: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
	}
},

highlight: function (e) {
	$(e).closest('.form-group').removeClass('has-info').addClass('has-error');
},
			
success: function (e) {
	$(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
	$(e).remove();
},
			
errorPlacement: function (error, element) {
	error.insertAfter(element.parent());
}
});

