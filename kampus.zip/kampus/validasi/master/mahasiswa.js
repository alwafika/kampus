// JavaScript Document By Afi
// AFI Validasi
$('#AFI-FORM').validate({
errorElement: 'div',
errorClass: 'help-block',
focusInvalid: false,
ignore: "",
rules: {
		fakultas: {
		required: true
		},
		
		progdi: {
		required: true
		},
		
		tahun: {
		required: true
		},
		
		namamhs: {
		required: true
		},
		
		tempatlahirmhs: {
		required: true
		},
		
		tanggallahirmhs: {
		required: true
		},
		
		alamatmhs: {
		required: true
		},
		
		kotamhs: {
		required: true
		},
		
		telpmhs: {
		required: true,
		number: true
		}
},
messages: {

		fakultas: {
		required: "Inputan diatas masih kosong, Silahkan pilih!"
		},
		
		progdi: {
		required: "Inputan diatas masih kosong, Silahkan pilih!"
		},
		
		tahun: {
		required: "Inputan diatas masih kosong, Silahkan pilih!"
		},
		
		namamhs: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		tempatlahirmhs: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		tanggallahirmhs: {
		required: "Inputan diatas masih kosong, Silahkan pilih!"
		},
		
		alamatmhs: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		kotamhs: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		telpmhs: {
		required: "Inputan diatas masih kosong, Silahkan diisi!",
		number: "Format inputan berupa angka!" 
		}
},

highlight: function (e) {
	$(e).closest('.form-group').removeClass('has-info').addClass('has-error');
},
			
success: function (e) {
	$(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
	$(e).remove();
},
			
errorPlacement: function (error, element) {
	error.insertAfter(element.parent());
}
});

