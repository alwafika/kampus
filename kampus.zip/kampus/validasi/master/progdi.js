// JavaScript Document By Afi
// AFI Validasi
$('#AFI-FORM').validate({
errorElement: 'div',
errorClass: 'help-block',
focusInvalid: false,
ignore: "",
rules: {
	kodeprogdi: {
		required: true,
		number: true
	},
	namaprogdi: {
		required: true
	},
	fakultas: {
		required: true
	}
},
messages: {
	kodeprogdi: {
		required: "Inputan diatas masih kosong, Silahkan diisi!",
		number: "Format inputan berupa Angka!"
	},
	namaprogdi: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
	},
	fakultas: {
		required: "Inputan diatas masih kosong, Silahkan pilih!"
	}
},

highlight: function (e) {
	$(e).closest('.form-group').removeClass('has-info').addClass('has-error');
},
			
success: function (e) {
	$(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
	$(e).remove();
},
			
errorPlacement: function (error, element) {
	error.insertAfter(element.parent());
}
});

