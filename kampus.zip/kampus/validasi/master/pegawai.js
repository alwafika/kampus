// JavaScript Document By Afi
// AFI Validasi
$('#AFI-FORM').validate({
errorElement: 'div',
errorClass: 'help-block',
focusInvalid: false,
ignore: "",
rules: {
			tahunpgw: {
			required: true
			},
			
			nik: {
			required: true,
			number: true
			},
			
			namapgw: {
			required: true
			},
			
			jekel: {
			required: true
			},
			
			agama: {
			required: true
			},
			
			tempatlahirpgw: {
			required: true
			},
			
			tanggallahirpgw: {
			required: true
			},
			
			alamatpgw: {
			required: true
			},
			
			kotapgw: {
			required: true
			},
			
			telppgw: {
			required: true,
			number:true
			},
			
			statuspgw: {
			required: true
			}
},
messages: {
		tahunpgw: {
		required: "Inputan diatas masih kosong, Silahkan dipilih!"
		},
		
		nik: {
		required: "Inputan diatas masih kosong, Silahkan diisi!",
		number: "Format inputan berupa Angka!"
		},
		
		namapgw: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		jekel: {
		required: "Inputan diatas masih kosong, Silahkan dipilih!"
		},
		
		agama: {
		required: "Inputan diatas masih kosong, Silahkan dipilih!"
		},
		
		tempatlahirpgw: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		tanggallahirpgw: {
		required: "Inputan diatas masih kosong, Silahkan dipilih!"
		},
		
		alamatpgw: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		kotapgw: {
		required: "Inputan diatas masih kosong, Silahkan diisi!"
		},
		
		telppgw: {
		required: "Inputan diatas masih kosong, Silahkan diisi!",
		number: "Format inputan berupa Angka!"
		},
		
		statuspgw: {
		required: "Inputan diatas masih kosong, Silahkan dipilih!"
		}
},

highlight: function (e) {
	$(e).closest('.form-group').removeClass('has-info').addClass('has-error');
},
			
success: function (e) {
	$(e).closest('.form-group').removeClass('has-error');//.addClass('has-info');
	$(e).remove();
},
			
errorPlacement: function (error, element) {
	error.insertAfter(element.parent());
}
});

