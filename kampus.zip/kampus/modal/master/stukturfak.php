<?php if (!defined('AFISYNTAX')) die('Access Denied'); ?>
<?php 
switch($url_afi){
	default:
			?>
<div class="modal-dialog"  role="document">
     <div class="modal-content">
     <div class="modal-header" role="document">
     	<h5 class="modal-title"><i class="fa fa-warning"></i> NOTICE</h5>
 		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     </div>
     <div class="modal-body">
    	<p>Tidak Ada Data Yang Ditampilkan <i style="color:#F00"></i></p>
     </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Tutup</button>
    </div>
</div>
<?php
	break;
	case md5($kunci.'Edit'):
?>
	<div class="modal-dialog"  role="document">
	<form class="modal-content" method="post" action="<?php echo $base_url.'/aksi/'.md5($kunci.'stukturfak');?>" enctype="multipart/form-data">
	<div class="modal-header" role="document">
    	<h5 class="modal-title"><i class="fa fa-edit"></i> Ubah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
	</div>
	<div class="modal-body">
	 <?php 
		$query	= $record->ihik('stuktur','*',NULL,'kodestuktur="'.$input['edit'].'"');
		switch(TRUE){
		case ($query->num_rows > 0):
		$data 	= $query->fetch_object();
	?>
                            <div class="form-group col-sm-12">
                			<?php inputText('Nama Jabatan','namastuktur',$data->namastuktur); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php textareaText('Tugas dan Fungsi','tugas',$data->tugas); ?>
                            </div> 
							<?php hiddenText('link','stukturfak'); hiddenText('kode',$input['edit']);?>
	
    <?php 
		break;
		default:
		echo'<p>Tidak Ada Data Yang Ditampilkan</p>';
		break;
		};
	?>
	</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Batal</button>
        <button type="submit" name="AFI" value="Update" class="btn btn-md btn-success"><i class="fa fa-level-up"></i> Update</button>
    </div>
    </form>
    </div>
   
 <?php
 	break;
	case md5($kunci.'Delete'):
 ?>
 <div class="modal-dialog"  role="document">
	<form class="modal-content" method="post" action="<?php echo $base_url.'/aksi/'.md5($kunci.'stukturfak');?>">
	<div class="modal-header" role="document">
    	<h5 class="modal-title"><i class="fa fa-trash"></i> Hapus Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
	</div>
	<div class="modal-body">
    	<p>Yakin Anda menghapus data tersebut <i style="color:#F00"></i></p>
		<p>Jika iya tekan tombol Hapus, jika tidak tekan tanda Batal</p>
         <?php hiddenText('link','stukturfak'); hiddenText('kode',$input['delete']);?>
	</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Batal</button>
        <button type="submit" name="AFI" value="Delete" class="btn btn-md btn-success"><i class="fa fa-trash"></i> Hapus</button>
    </div>
    </form>
    </div>
 <?php
	break;
  };?>