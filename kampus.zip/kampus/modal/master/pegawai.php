<?php if (!defined('AFISYNTAX')) die('Access Denied'); ?>
<?php 
switch($url_afi){
	default:
			?>
<div class="modal-dialog"  role="document">
     <div class="modal-content">
     <div class="modal-header" role="document">
     	<h5 class="modal-title"><i class="fa fa-warning"></i> NOTICE</h5>
 		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     </div>
     <div class="modal-body">
    	<p>Tidak Ada Data Yang Ditampilkan <i style="color:#F00"></i></p>
     </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Tutup</button>
    </div>
</div>
<?php
	break;
	case md5($kunci.'Edit'):
?>
	<div class="modal-dialog"  role="document">
	<form class="modal-content" method="post" action="<?php echo $base_url.'/aksi/'.md5($kunci.'pegawai');?>" enctype="multipart/form-data">
	<div class="modal-header" role="document">
    	<h5 class="modal-title"><i class="fa fa-edit"></i> Ubah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
	</div>
	<div class="modal-body">
	 <?php 
		$query	= $record->ihik('pegawai','*',NULL,'kodepgw="'.$input['edit'].'"');
		switch(TRUE){
		case ($query->num_rows > 0):
		$data 	= $query->fetch_object();
		$isi	= array('AKTIF','NON AKTIF');
		$tgl	= array();
		$mulai	= date('Y') - 40;
		while($mulai <= date('Y')){
		$tgl[]	= $mulai++;
		};
                        ?>
                            <div class="form-group col-sm-12">
                			<?php selectTexted('Tahun Masuk','tahunpgw',$tgl,$data->tahunpgw); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('NIK','nik',$data->nik); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('Nama Karyawan','namapgw',$data->namapgw); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php  selectBase('Jenis Kelamin','jekel','jekel','kodejekel','namajekel',$data->jekel,$_user,$_name,$_pass,$host); ?>
                            </div>
                            <div class="form-group col-sm-12">
                			<?php  selectBase('Agama','agama','agama','kodeagama','namaagama',$data->agama,$_user,$_name,$_pass,$host); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('Tempat Lahir','tempatlahirpgw',$data->tempatlahirpgw); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('Tanggal Lahir (Format: Tahun-Bulan-Tanggal)','tanggallahirpgwx',$data->tanggallahirpgw); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php textareaText('Alamat Lengkap','alamatpgw',$data->alamatpgw); ?>
                            </div>
                            <div class="form-group col-sm-12">
                			<?php inputText('Kota','kotapgw',$data->kotapgw); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('No. Telp/HP','telppgw',$data->telppgw); ?>
                            </div>
                            <div class="form-group col-sm-12">
                			<?php  selectBase('Status Karyawan','statuspgw','statuspgw','kodestatuspgw','namastatuspgw',$data->statuspgw,$_user,$_name,$_pass,$host); ?>
                            </div> 
							<?php hiddenText('kode',$input['edit']);?>
	
    <?php 
		break;
		default:
		echo'<p>Tidak Ada Data Yang Ditampilkan</p>';
		break;
		};
	?>
    <script type="text/javascript">
	 $("#tanggallahirpgwx").datepicker({
			dateFormat: "yy-mm-dd",
			changeMonth: true,
			changeYear: true,
			yearRange: "<?php echo date('Y')-70;?>: <?php echo date ('Y');?>",
			showAnim: "slide",
			});	
	</script>
	</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Batal</button>
        <button type="submit" name="AFI" value="Update" class="btn btn-md btn-success"><i class="fa fa-level-up"></i> Update</button>
    </div>
    </form>
    </div>
   
 <?php
 	break;
	case md5($kunci.'Delete'):
 ?>
 <div class="modal-dialog"  role="document">
	<form class="modal-content" method="post" action="<?php echo $base_url.'/aksi/'.md5($kunci.'pegawai');?>">
	<div class="modal-header" role="document">
    	<h5 class="modal-title"><i class="fa fa-trash"></i> Hapus Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
	</div>
	<div class="modal-body">
    	<p>Yakin Anda menghapus data tersebut <i style="color:#F00"></i></p>
		<p>Jika iya tekan tombol Hapus, jika tidak tekan tanda Batal</p>
         <?php hiddenText('kode',$input['delete']);?>
	</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Batal</button>
        <button type="submit" name="AFI" value="Delete" class="btn btn-md btn-success"><i class="fa fa-trash"></i> Hapus</button>
    </div>
    </form>
    </div>
 <?php
	break;
  };?>