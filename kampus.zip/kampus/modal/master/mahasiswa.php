<?php if (!defined('AFISYNTAX')) die('Access Denied'); ?>
<?php 
switch($url_afi){
	default:
			?>
<div class="modal-dialog"  role="document">
     <div class="modal-content">
     <div class="modal-header" role="document">
     	<h5 class="modal-title"><i class="fa fa-warning"></i> NOTICE</h5>
 		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     </div>
     <div class="modal-body">
    	<p>Tidak Ada Data Yang Ditampilkan <i style="color:#F00"></i></p>
     </div>
	 <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Tutup</button>
    </div>
</div>
<?php
	break;
	case md5($kunci.'PilihProg'):
		selectWhere('Progam Studi','progdi','progdi','kodeprogdi','namaprogdi','fakultas="'.$input['detail'].'"',NULL,$_user,$_name,$_pass,$host);
	break;
	case md5($kunci.'Edit'):
?>
	<div class="modal-dialog"  role="document">
	<form class="modal-content" method="post" action="<?php echo $base_url.'/aksi/'.md5($kunci.'mahasiswa');?>" enctype="multipart/form-data">
	<div class="modal-header" role="document">
    	<h5 class="modal-title"><i class="fa fa-edit"></i> Ubah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
	</div>
	<div class="modal-body">
	 <?php 
		$query	= $record->ihik('mahasiswa','*',NULL,'kodemhs="'.$input['edit'].'"');
		switch(TRUE){
		case ($query->num_rows > 0):
		$data 	= $query->fetch_object();
		$isi	= array('AKTIF','NON AKTIF');
	?>
                			 <div class="form-group col-sm-12">
                			<?php inputText('NIK','nik',$data->nik); ?>
                            </div>  
                            <div class="form-group col-sm-12">
                			<?php inputText('Nama Mahasiswa','namamhs',$data->namamhs); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php  selectBase('Jenis Kelamin','jekel','jekel','kodejekel','namajekel',$data->jekel,$_user,$_name,$_pass,$host); ?>
                            </div>
                             <div class="form-group col-sm-12">
                			<?php  selectBase('Agama','agama','agama','kodeagama','namaagama',$data->agama,$_user,$_name,$_pass,$host); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('Tempat Lahir','tempatlahirmhs',$data->tempatlahirmhs); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('Tanggal Lahir (Format: Tahun-Bulan-Tanggal)','tanggallahirmhsx',$data->tanggallahirmhs); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php textareaText('Alamat Lengkap','alamatmhs',$data->alamatmhs); ?>
                            </div>
                            <div class="form-group col-sm-12">
                			<?php inputText('Kota Mahasiswa','kotamhs',$data->kotamhs); ?>
                            </div> 
                            <div class="form-group col-sm-12">
                			<?php inputText('No. Telp/HP','telpmhs',$data->telpmhs); ?>
                            </div> 
                             <div class="form-group col-sm-12">
                			<?php selectTexted('Status','status',$isi,$data->status); ?>
                            </div>  
							<?php hiddenText('kode',$input['edit']);?>
	
    <?php 
		break;
		default:
		echo'<p>Tidak Ada Data Yang Ditampilkan</p>';
		break;
		};
	?>
    <script type="text/javascript">
	 $("#tanggallahirmhsx").datepicker({
			dateFormat: "yy-mm-dd",
			changeMonth: true,
			changeYear: true,
			yearRange: "1990: <?php echo date ('Y');?>",
			showAnim: "slide",
			});	
	</script>
	</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Batal</button>
        <button type="submit" name="AFI" value="Update" class="btn btn-md btn-success"><i class="fa fa-level-up"></i> Update</button>
    </div>
    </form>
    </div>
   
 <?php
 	break;
	case md5($kunci.'Delete'):
 ?>
 <div class="modal-dialog"  role="document">
	<form class="modal-content" method="post" action="<?php echo $base_url.'/aksi/'.md5($kunci.'mahasiswa');?>">
	<div class="modal-header" role="document">
    	<h5 class="modal-title"><i class="fa fa-trash"></i> Hapus Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
	</div>
	<div class="modal-body">
    	<p>Yakin Anda menghapus data tersebut <i style="color:#F00"></i></p>
		<p>Jika iya tekan tombol Hapus, jika tidak tekan tanda Batal</p>
         <?php hiddenText('kode',$input['delete']);?>
	</div>
    <div class="modal-footer">
        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><i class="fa fa-ban"></i> Batal</button>
        <button type="submit" name="AFI" value="Delete" class="btn btn-md btn-success"><i class="fa fa-trash"></i> Hapus</button>
    </div>
    </form>
    </div>
 <?php
	break;
  };?>