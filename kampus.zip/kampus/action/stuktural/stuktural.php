<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
switch($url_afi){
	default:
			header('location: '.$base_url);
	break;
	case 'Save':
		switch(TRUE){
			case substr_count($input['pegawai'],' || ')> '0':
				$pegawai	= explode(' || ',$input['pegawai']);		
				$aksi		= $record->ngesex('stuktural',
												array(		
															'fakultas'				=> $input['fakultas'],
															'progdi'				=> $input['progdi'],
															'stuktur'				=> $input['stuktur'],
															'pegawai'				=> $pegawai[0],
															'periode'				=> $input['periode'],
															'lembaga'				=> $input['lembaga'],
															'statusstuktur'			=> 'AKTIF'));
				switch(TRUE){
					case $aksi:
							header('location: '.$base_url.'/'.$input['link'].'/sukses');
					break;
					default:
							header('location: '.$base_url.'/'.$input['link'].'/gagal');
					break;
				};
			break;
			default:
				header('location: '.$base_url.'/'.$input['link'].'/gagal');
			break;
		};
	break;
	case 'Update':
				$aksi		= $record->ngentot('stuktural','kodestuktural="'.$input['kode'].'"',
											array(	
															'stuktur'				=> $input['stuktur'],
															'periode'				=> $input['periode'],
															'statusstuktur'			=> $input['statusstuktur']));
				switch(TRUE){
					case $aksi:
							header('location: '.$base_url.'/'.$input['link'].'/sukses');
					break;
					default:
							header('location: '.$base_url.'/'.$input['link'].'/gagal');
					break;
				};
	break;
	case 'Delete':
					$aksi		= $record->ngecrot('stuktural','kodestuktural="'.$input['kode'].'"');
					switch(TRUE){
						case $aksi:
								header('location: '.$base_url.'/'.$input['link'].'/sukses');
						break;
						default:
								header('location: '.$base_url.'/'.$input['link'].'/gagal');
						break;
				};
					
	break;
};
?>