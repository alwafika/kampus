<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
switch($url_data){
		
		/* AKSI MASTER */
		case md5($kunci.'fakultas'):
			require('action/master/fakultas.php');
		break;
		case md5($kunci.'progdi'):
			require('action/master/progdi.php');
		break;
		case md5($kunci.'mahasiswa'):
			require('action/master/mahasiswa.php');
		break;
		case md5($kunci.'makul'):
			require('action/master/makul.php');
		break;
		case md5($kunci.'pegawai'):
			require('action/master/pegawai.php');
		break;
		case md5($kunci.'stukturuniv'):
			require('action/master/stuktur.php');
		break;
		case md5($kunci.'stukturfak'):
			require('action/master/stuktur.php');
		break;
		case md5($kunci.'stukturprogdi'):
			require('action/master/stuktur.php');
		break;
		case md5($kunci.'nonakademik'):
			require('action/master/nonakademik.php');
		break;
		
		/* AKSI stuktural */
		case md5($kunci.'stukturaluniv'):
			require('action/stuktural/stuktural.php');
		break;
		case md5($kunci.'stukturalfak'):
			require('action/stuktural/stuktural.php');
		break;
		
		/*DEFAULT*/
		default:
			require('modul/home/load.php');
		break;
};
?>