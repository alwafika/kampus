<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
switch($url_data){
	
	/* MASTER DATA */
	case md5($kunci.'fakultas'):
								require('table/master/fakultas.php');
	break;
	case md5($kunci.'progdi'):
								require('table/master/progdi.php');
	break;
	case md5($kunci.'mahasiswa'):
								require('table/master/mahasiswa.php');
	break;
	case md5($kunci.'makul'):
								require('table/master/makul.php');
	break;
	case md5($kunci.'pegawai'):
								require('table/master/pegawai.php');
	break;
	case md5($kunci.'stukturuniv'):
								require('table/master/stukturuniv.php');
	break;
	case md5($kunci.'nonakademik'):
								require('table/master/nonakademik.php');
	break;
	case md5($kunci.'stukturfak'):
								require('table/master/stukturfak.php');
	break;
	case md5($kunci.'stukturprogdi'):
								require('table/master/stukturprogdi.php');
	break;
	
	/* stuktural */
	case md5($kunci.'stukturaluniv'):
								require('table/stuktural/stukturaluniv.php');
	break;
	case md5($kunci.'stukturalfak'):
								require('table/stuktural/stukturalfak.php');
	break;
		
	
	
	/*DEFAULT*/
	default:
	echo '{"iTotalRecords":"0","iTotalDisplayRecords":"0","aaData":[]}';
	break;	
};
$record->close();
?>