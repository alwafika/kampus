<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
switch($url_data){
	
	/* MASTER DATA */
	case md5($kunci.'fakultas'):
			require('modal/master/fakultas.php');
	break;
	case md5($kunci.'progdi'):
			require('modal/master/progdi.php');
	break;
	case md5($kunci.'mahasiswa'):
			require('modal/master/mahasiswa.php');
	break;
	case md5($kunci.'makul'):
			require('modal/master/makul.php');
	break;
	case md5($kunci.'pegawai'):
			require('modal/master/pegawai.php');
	break;
	case md5($kunci.'stukturuniv'):
			require('modal/master/stukturuniv.php');
	break;
	case md5($kunci.'nonakademik'):
			require('modal/master/nonakademik.php');
	break;
	case md5($kunci.'stukturfak'):
			require('modal/master/stukturfak.php');
	break;
	case md5($kunci.'stukturprogdi'):
			require('modal/master/stukturprogdi.php');
	break;
	
	/* stuktural */
	case md5($kunci.'stukturaluniv'):
			require('modal/stuktural/stukturaluniv.php');
	break;
	case md5($kunci.'stukturalfak'):
			require('modal/stuktural/stukturalfak.php');
	break;
	/*DEFAULT*/
	case md5($kunci.'zoom'):
			require('modal/image/perbesar.php');
	break;
	default:
			require('modal/default.php');
	break;
};
