<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
switch($url_page){	
	/*DEFAULT ========================================================================================================================== */
	default:
			require('modul/home/load.php');
	break;
	case'':
			require('modul/home/load.php');
	break;	
	
	/* MASTER DATA ===================================================================================================================== */
	case'fakultas': 
			require('modul/master/load.php');
	break;
	case'progdi': 
			require('modul/master/load.php');
	break;
	case'stukturuniv': 
			require('modul/master/load.php');
	break;
	case'nonakademik': 
			require('modul/master/load.php');
	break;
	case'stukturfak': 
			require('modul/master/load.php');
	break;
	case'stukturprogdi': 
			require('modul/master/loadtiga.php');
	break;
	case'mahasiswa': 
			require('modul/master/loaddua.php');
	break;
	case'makul': 
			require('modul/master/loadtiga.php');
	break;
	case'pegawai': 
			require('modul/master/loadempat.php');
	break;
	
	/* stuktural ===================================================================================================================== */
	case'stukturaluniv': 
			require('modul/stuktural/load.php');
	break;	
	case'stukturalfak': 
			require('modul/stuktural/loaddua.php');
	break;	
	case'stukturalprogdi': 
			require('modul/stuktural/loadtiga.php');
	break;	

	/* LAPORAN ====================================================================================================================== */

	
};
?>