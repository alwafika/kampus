<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
$record = new mysqli('localhost',$_user,$_pass,$_name);
function uang($number) {
		switch(TRUE){
		case(!empty($number)):
		$bilangan = number_format($number, 0, ",", "."); 
		return $bilangan."";
		break;
		default:
			$bilangan = $number;
			return $bilangan;
		break;
		};
	};
function telp($number) {
		switch(TRUE){
		case(!empty($number)):
		$bilangan = '+62'.number_format($number, 0, ",", " "); 
		return $bilangan."";
		break;
		default:
			$bilangan = '+62'.$number;
			return $bilangan;
		break;
		};
	};
function indotgl($tgl) {
	$tanggal = explode("-",$tgl);
	$hari = $tanggal[2];
	$hari = explode(' ',$hari);
	switch(TRUE){
	case(empty($hari[1])): $jam = '';break; default: $jam = $hari[1]; break;};
	$ar_bulan = array(1=>'Januari','Februari','Maret', 'April', 'Mei', 'Juni','Juli','Agustus','September','Oktober', 'November','Desember');
	
	switch(TRUE){case(empty($hari[0])): $hari = ''; break; default: $hari = $hari[0]; break;};
	switch(TRUE){case(empty($ar_bulan[abs($tanggal[1])])): $bulan = ''; break; default: $bulan = $ar_bulan[abs($tanggal[1])]; break;};
	switch(TRUE){case(empty($tanggal[0])): $tahun = ''; break; default: $tahun = $tanggal[0]; break;};

	$tanggal = $hari.' '.$bulan.' '.$tahun.' '.$jam;
	switch(TRUE){
	case($tahun == '0000'):
		return '-';
	break;
	default:
		return $tanggal;
	break;
	};
};
function indtgl($tgl) {
	$tanggal = explode("-",$tgl);
	$hari = $tanggal[2];
	$hari = explode(' ',$hari);
	switch(TRUE){
	case(empty($hari[1])): $jam = '';break; default: $jam = $hari[1]; break;};
	$ar_bulan = array(1=>'Jan','Feb','Mar', 'Apr', 'Mei', 'Jun','Jul','Agu','Sep','Okt', 'Nov','Des');
	
	switch(TRUE){case(empty($hari[0])): $hari = ''; break; default: $hari = $hari[0]; break;};
	switch(TRUE){case(empty($ar_bulan[abs($tanggal[1])])): $bulan = ''; break; default: $bulan = $ar_bulan[abs($tanggal[1])]; break;};
	switch(TRUE){case(empty($tanggal[0])): $tahun = ''; break; default: $tahun = $tanggal[0]; break;};

	$tanggal = $hari.'-'.$bulan.'-'.$tahun.' '.$jam;
	switch(TRUE){
	case($tahun == '0000'):
		return '-';
	break;
	default:
		return $tanggal;
	break;
	};
};
function tgl ($tgl) {
	switch(TRUE){case(!empty($tgl)):
	$tanggal = explode("-",$tgl);
	$tahun = $tanggal[0];
	$bulan = $tanggal[1];
	$ar_hari = explode(' ',$tanggal[2]);
	$hari = $ar_hari[0];
	switch(TRUE){case(empty($ar_hari[1])) :$jam = ''; break; default: $jam = $ar_hari[1]; break;};
	$tanggal = $hari.'-'.$bulan.'-'.$tahun.' '.$jam;
	$tanggal = trim($tanggal);
	return $tanggal;
	break;
	default:
		$tanggal = $tgl;
		return $tgl;
	break;
	};
};
?>

