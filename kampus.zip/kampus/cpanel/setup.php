<?php
define('AFISYNTAX',TRUE);
mb_internal_encoding('UTF-8');
date_default_timezone_set("Asia/Jakarta");
set_time_limit(6000);

/* SETUP ANTI CRASH PEMANGGILAN DATA --------------------------------------------------------------------------------------- */
global $base_url;
global $url_page;
global $url_data;
global $url_hal;
global $url_lain;
global $url_ples;
global $url_akhir;
global $url_next;
global $sesi;
global $input;
global $get;
global $up;
global $_pass;
global $_user;
global $_name;
global $host;
global $kunci;
global $url_afi;
global $url_upload;
/* END ANTI CRASH PEMANGGILAN DATA --------------------------------------------------------------------------------------- */

$base_url			= 'http://localhost/kampus'; // ALAMAT LINK 

/* SETUP HTACCESS--------------------------------------------------------------------------------------- */
$link 				= preg_replace('/[^A-Za-z0-9\/]/','',$_SERVER['REQUEST_URI']);
$url 				= (explode('/',$link));
$url_page  			= isset($url[2]) ? $url[2] : NULL;
$url_data  			= isset($url[3]) ? $url[3] : NULL;
$url_hal   			= isset($url[4]) ? $url[4] : NULL;
$url_lain  			= isset($url[5]) ? $url[5] : NULL;
$url_ples  			= isset($url[6]) ? $url[6] : NULL;
$url_akhir 			= isset($url[7]) ? $url[7] : NULL;
$url_next  			= isset($url[8]) ? $url[8] : NULL;
/* END HTACCESS--------------------------------------------------------------------------------------- */

/* FORMAT PHP 7 KEATAS SAMPAI PHP UDAH MATI  ---------------------------------------------------------------------------------- */
$sesi				=& $_SESSION;
$input				=& $_POST;
$get				=& $_GET;
$up					=& $_FILES;
$url_afi			= isset($input['AFI']) ? $input['AFI'] : NULL;
$url_upload			= $base_url.'/images/default/upload.png';
/* END FORMAT PHP 7 SAMPAI PHP UDAH MATI KEATAS --------------------------------------------------------------------------------------- */

/* --------------membuat licensi aplikasi-------------------------------------------------------------------------------------------------------------------------------------------------- */
switch(TRUE){
	case empty($sesi['kunci']):
					$sesi['kunci']		= mt_rand(1,10000000);
					$kunci				= $sesi['kunci'];
	break;
	default:
					$kunci				= $sesi['kunci'];
	break;
};
$sesi['register']	= '20190814155922'; // KODE REGISTER APLIKASI
$_pass				= '';	// PASSWORD DATABASE
$_user				= 'root'; // USER DATABASE
$_name				= 'kampus'; // NAMA DATABASE
$host				= 'localhost'; // SERVER HOST DATABASE
?>