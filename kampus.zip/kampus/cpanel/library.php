<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
function heading($link){
echo'<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1.0" name="viewport">
		<meta content="" name="keywords"><meta content="" name="description">
		<link href="'.$link.'/images/logo/demak.png" rel="icon">
		<link href="'.$link.'/images/logo/demak.png" rel="apple-touch-icon">
		<link href="'.$link.'/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="'.$link.'/assets/css/font-awesome.min.css" rel="stylesheet">
		<link href="'.$link.'/assets/css/animate.min.css" rel="stylesheet">
		<link rel="stylesheet" href="'.$link.'/assets/css/jquery-ui.min.css"/>
		<link rel="stylesheet" href="'.$link.'/assets/css/jquery.ui.css"/>
		<link href="'.$link.'/assets/css/style.css" rel="stylesheet">
		<script src="'.$link.'/assets/js/jquery.js" type="text/javascript"></script>
	</head>
';
};
function headingdua($link){
echo'<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta content="width=device-width, initial-scale=1.0" name="viewport">
		<meta content="" name="keywords"><meta content="" name="description">
		<link href="'.$link.'/images/logo/demak.png" rel="icon">
		<link href="'.$link.'/images/logo/demak.png" rel="apple-touch-icon">
		<link href="'.$link.'/assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="'.$link.'/assets/css/font-awesome.min.css" rel="stylesheet">
		<link href="'.$link.'/assets/css/animate.min.css" rel="stylesheet">
		<link rel="stylesheet" href="'.$link.'/assets/css/jquery-ui.min.css"/>
		<link rel="stylesheet" href="'.$link.'/assets/css/jquery.ui.css"/>
		<link href="'.$link.'/assets/css/stile.css" rel="stylesheet">
		<script src="'.$link.'/assets/js/jquery.js" type="text/javascript"></script>
	</head>
';
};

function breadcrumb($link,$title){?>
<nav>
	<ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo $link;?>"><span class="fa fa-home"></span> Home</a></li>
        <li class="breadcrumb-item active"><?php echo $title;?></li>
	</ol>
</nav>
<?php };
function message($message){
	switch($message){
		default:
		$keterangan='';
		break;
		
		case '1':
		$keterangan='
					<div class="alert bg-success alert-dismissable text-white">
       					<i class="fa fa-check"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Sukses!</b> Proses yang Anda lakukan berhasil...Pendaftaran Akan di Proses oleh Admin
       				</div>
		';			
		break;
		case 'sukses':
		$keterangan='
					<div class="alert bg-success alert-dismissable text-white">
       					<i class="fa fa-check"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Sukses!</b> Proses yang Anda lakukan berhasil...
       				</div>
		';			
		break;
		case 'gagal':
		$keterangan='
					<div class="alert bg-danger alert-dismissable text-white">
       					<i class="fa fa-ban"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Maaf..</b> Proses mengalami kegagalan atau ada kesamaan data,  Silahkan Cek!
       				</div>
			';
		break;
		case 'nominal':
		$keterangan='
					<div class="alert bg-danger alert-dismissable text-white">
       					<i class="fa fa-ban"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Gagal..</b> Proses mengalami kegagalan,Nominal Pembayaran melebihi jumlah Hutang/Piutang atau Tanggal Pembayaran Salah,  Silahkan Cek!
       				</div>
			';
		break;
		
		case 'jumlah':
		$keterangan='
					<div class="alert bg-danger alert-dismissable text-white">
       					<i class="fa fa-ban"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Gagal..</b> Jumlah Melebihi Stok Yang Ada, atau Tanggal Pembelian Salah,  Silahkan Cek!
       				</div>
			';
		break;
		case 'plagiat':
		$keterangan='
					<div class="alert bg-warning alert-dismissable text-white">
       					<i class="fa fa-warning"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Maaf..</b> Proses input gagal. Ada kesamaan data dalam proses input!
       				</div>
			';
		break;
		case 'ekstensi':
		$keterangan='
					<div class="alert bg-warning alert-dismissable">
       					<i class="fa fa-warning"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Maaf..</b> Proses input gagal. Format Extentesi File Salah!
       				</div>
			';
		break;
		case 'large':
		$keterangan='
					<div class="alert bg-warning alert-dismissable">
       					<i class="fa fa-warning"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Maaf..</b> Proses input gagal. Upload Foto melebihi batas! Max Upload 1MB
       				</div>
			';
		break;
		case 'koreksi':
		$keterangan='
					<div class="alert bg-warning alert-dismissable text-white">
       					<i class="fa fa-warning"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Login Gagal..</b> Koreksi Email atau password anda, jika masih gagal, hubungi Admin
       				</div>
			';
		break;
		case 'fail':
		$keterangan='
					<div class="alert bg-warning alert-dismissable text-white">
       					<i class="fa fa-warning"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Maaf..</b> Data Sudah Terinput/berkaitan dengan Transaksi yang lain, Silahkan Cek!!
       				</div>
			';
		break;
		case 'salah':
		$keterangan='
					<div class="alert bg-warning alert-dismissable text-white">
       					<i class="fa fa-warning"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Maaf..</b> Data Yang Anda Inputkan Salah, Silahkan lakukan koreksi!!
       				</div>
			';
		break;
		case 'captchasalah':
		$keterangan='
					<div class="alert bg-warning alert-dismissable text-white">
       					<i class="fa fa-warning"></i>
         				<button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times"></i></button>
          				<b>Maaf..</b> Captcha Yang Anda Inputkan Salah, Silahkan lakukan koreksi!!
       				</div>
			';
		break;
	};
	echo $keterangan;	
};

function tab_1(){
	?>
	<ul class="nav nav-tabs nav-pills" id="myTab" role="tablist">
      <li class="nav-item">
        <a class="nav-link active" data-toggle="tab" href="#tabeldata" role="tab" aria-selected="true"><span class="fa fa-table"></span> Tabel Data</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-toggle="tab" href="#insertdata" role="tab" aria-selected="false"><span class="fa fa-edit"></span> Tambah Data</a>
      </li>
</ul>
<?php
};

function titleContent($icon,$nama){
	echo'
	<div class="card-header shadow">
		<h6 class="pull-left"><i class="'.$icon.'"></i> <span>'.$nama.'</span></h6>
					<div class="widget-toolbar pull-right">
                        <a href="" data-action="reload" data-rel="tooltip" title="Refresh Halaman" class="refresh">
                            <i class="ace-icon fa fa-refresh"></i>
                        </a>
                    </div>
	</div>
		 ';
};
function contentTitle($icon,$nama,$back){
	echo'
	<div class="card-header shadow">
            		<h6 class="pull-left"><i class="fa '.$icon.'"></i> <span>'.$nama.'</span></h6>
                    <div class="widget-toolbar pull-right">
                        <a href="" data-action="reload" data-rel="tooltip" title="Refresh Halaman" class="refresh">
                            <i class="ace-icon fa fa-refresh"></i>
                        </a>
                    </div>
					<div class="pull-right">
                        <a href="'.$back.'"  data-rel="tooltip" title="Kembali ke Halaman Sebelumnya">
                            <i class="ace-icon fa fa-undo"></i>
                        </a>
                    </div>
            </div>
		 ';
};

function content($icon,$nama){
	echo'
	<div class="card-header shadow">
            		<h6 class="pull-left"><i class="fa '.$icon.'"></i> <span>'.$nama.'</span></h6>
                    
            </div>
		 ';
};
function printContent($icon,$nama){
	echo'
	<div class="card-header shadow">
            		<h6 class="pull-left"><i class="fa '.$icon.'"></i> <span>'.$nama.'</span></h6>
                    <div class="widget-toolbar pull-right">
                        <a href="" data-action="reload" data-rel="tooltip" title="Refresh Halaman" class="refresh">
                            <i class="ace-icon fa fa-refresh"></i>
                        </a>
						&nbsp;
                        <a href="#"  data-rel="tooltip" title="Cetak" onclick="window.print()" class="print">
                            <i class="ace-icon fa fa-print"></i>
                        </a>
                    </div>
            </div>
		 ';
};
function contentPrint($icon,$nama,$back){
			echo'
					<div class="card-header shadow">
            		<h6 class="pull-left"><i class="fa '.$icon.'"></i> <span>'.$nama.'</span></h6>
					<div class="widget-toolbar pull-right">
						<a href="'.$back.'"  data-rel="tooltip" title="Kembali ke Halaman Sebelumnya">
                            <i class="ace-icon fa fa-undo"></i>
                        </a>
						&nbsp;
                        <a href="#"  data-rel="tooltip" title="Cetak" onclick="window.print()" class="print">
                            <i class="ace-icon fa fa-print"></i>
                        </a>
                    </div>
					
            </div>
		 ';
};
function uang($number) {
		switch(TRUE){
		case(!empty($number)):
		$bilangan = number_format($number, 0, ",", "."); 
		return $bilangan."";
		break;
		default:
			$bilangan = $number;
			return $bilangan;
		break;
		};
	};
function telp($number) {
		switch(TRUE){
		case(!empty($number)):
		$bilangan = '+62'.number_format($number, 0, ",", " "); 
		return $bilangan."";
		break;
		default:
			$bilangan = '+62'.$number;
			return $bilangan;
		break;
		};
	};
function indotgl($tgl) {
	$tanggal = explode("-",$tgl);
	$hari = $tanggal[2];
	$hari = explode(' ',$hari);
	switch(TRUE){
	case(empty($hari[1])): $jam = '';break; default: $jam = $hari[1]; break;};
	$ar_bulan = array(1=>'Januari','Februari','Maret', 'April', 'Mei', 'Juni','Juli','Agustus','September','Oktober', 'November','Desember');
	
	switch(TRUE){case(empty($hari[0])): $hari = ''; break; default: $hari = $hari[0]; break;};
	switch(TRUE){case(empty($ar_bulan[abs($tanggal[1])])): $bulan = ''; break; default: $bulan = $ar_bulan[abs($tanggal[1])]; break;};
	switch(TRUE){case(empty($tanggal[0])): $tahun = ''; break; default: $tahun = $tanggal[0]; break;};

	$tanggal = $hari.' '.$bulan.' '.$tahun.' '.$jam;
	switch(TRUE){
	case($tahun == '0000'):
		return '~';
	break;
	default:
		return $tanggal;
	break;
	};
};
function intgl($tgl) {
	$tanggal = explode("-",$tgl);
	$hari = $tanggal[2];
	$hari = explode(' ',$hari);
	switch(TRUE){
	case(empty($hari[1])): $jam = '';break; default: $jam = $hari[1]; break;};
	$ar_bulan = array(1=>'Januari','Februari','Maret', 'April', 'Mei', 'Juni','Juli','Agustus','September','Oktober', 'November','Desember');
	
	switch(TRUE){case(empty($hari[0])): $hari = ''; break; default: $hari = $hari[0]; break;};
	switch(TRUE){case(empty($ar_bulan[abs($tanggal[1])])): $bulan = ''; break; default: $bulan = $ar_bulan[abs($tanggal[1])]; break;};
	switch(TRUE){case(empty($tanggal[0])): $tahun = ''; break; default: $tahun = $tanggal[0]; break;};

	$tanggal = $hari.' '.$bulan.' '.$tahun;
	switch(TRUE){
	case($tahun == '0000'):
		return '~';
	break;
	default:
		return $tanggal;
	break;
	};
};
function tgl ($tgl) {
	switch(TRUE){case(!empty($tgl)):
	$tanggal = explode("-",$tgl);
	$tahun = $tanggal[0];
	$bulan = $tanggal[1];
	$ar_hari = explode(' ',$tanggal[2]);
	$hari = $ar_hari[0];
	switch(TRUE){case(empty($ar_hari[1])): $jam = ''; break; default: $jam = $ar_hari[1]; break;};
	$tanggal = $hari.'-'.$bulan.'-'.$tahun.' '.$jam;
	$tanggal = trim($tanggal);
	return $tanggal;
	break;
	default:
		$tanggal = $tgl;
		return $tgl;
	break;
	};
};
function kalender ($tgl) {
	switch(TRUE){case(!empty($tgl)):
	$tanggal = explode("-",$tgl);
	$tahun = $tanggal[0];
	$bulan = $tanggal[1];
	$ar_hari = explode(' ',$tanggal[2]);
	$hari = $ar_hari[0];
	switch(TRUE){case(empty($ar_hari[1])): $jam = ''; break; default: $jam = $ar_hari[1]; break;};
	$tanggal = $hari.'/'.$bulan.'/'.$tahun.' '.$jam;
	$tanggal = trim($tanggal);
	return $tanggal;
	break;
	default:
		$tanggal = $tgl;
		return $tgl;
	break;
	}
};
function Terbilang($x){
  $abil = array(" ", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas");
  switch(TRUE){
	  	case($x < 12):
    		return " " . $abil[$x];
		break;
  		case($x < 20):
    		return Terbilang($x - 10) . " Belas";
		break;
  		case($x < 100):
    		return Terbilang($x / 10) . " puluh" . Terbilang($x % 10);
		break;
  		case($x < 200):
   			return " Seratus" . Terbilang($x - 100);
  		break;
		case($x < 1000):
    		return Terbilang($x / 100) . " ratus" . Terbilang($x % 100);
  		break;
		case($x < 2000):
    		return " Seribu" . Terbilang($x - 1000);
 		break;
		case($x < 1000000):
    		return Terbilang($x / 1000) . " Ribu" . Terbilang($x % 1000);
		break;
  		case($x < 1000000000):
    		return Terbilang($x / 1000000) . " Juta" . Terbilang($x % 1000000);
		break;
  };
};

function bulanInd($tgl) {
	$ar_bulan = array(1=>'Januari','Februari','Maret', 'April', 'Mei', 'Juni','Juli','Agustus','September','Oktober', 'November','Desember');
	$arx = $tgl;
	  switch(TRUE){
	  	case(substr($arx,0,1)==0):
		$ar = substr($arx,1,1);
		break;
		default:
		$ar = $arx;
		break;
	  };
	$bulan = $ar_bulan[$ar];
	return $bulan;
};
?>