<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
function compress_foto($source_url) {
    $source_info = getimagesize($source_url);  
	switch($source_info['mime']){
	case 'image/jpeg': $gambar = imagecreatefromjpeg($source_url);
	break;
	case'image/gif': $gambar = imagecreatefromgif($source_url);
	break;
    case 'image/png': $gambar = imagecreatefrompng($source_url);
	break;
	};
    imagejpeg($gambar, $source_url,10);
};
function kompress_foto($source_url) {
    $source_info = getimagesize($source_url);  
	switch($source_info['mime']){
	case 'image/jpeg': $gambar = imagecreatefromjpeg($source_url);
	break;
	case'image/gif': $gambar = imagecreatefromgif($source_url);
	break;
    case 'image/png': $gambar = imagecreatefrompng($source_url);
	break;
	};
    imagejpeg($gambar, $source_url,20);
};
function notaKode($kodeNota,$tabel,$field,$kode,$_user,$_name,$_pass) {
	$get_rec = new ngaceng;
	$get_rec->kukentukamu($_user,$_name,$_pass);
	$tahun = date("Y");
	$bulan = array(1 => "I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII");
	$arx = date("m");
	switch(TRUE){
		case(substr($arx,0,1)==0):
		$ar = substr($arx,1,1);
		break;
		default:
		$ar = $arx;
		break;
	};
	$bulanRomawi = $bulan[$ar];
	$jum = strlen($bulanRomawi);
	switch($jum){
	case'1':
		$sisipan = 'substr('.$field.',13,1)';
	break;
	case'2':
		$sisipan = 'substr('.$field.',13,2)';
	break;
	case'3':
		$sisipan = 'substr('.$field.',13,3)';
	break;
	default:
		$sisipan = 'substr('.$field.',13,4)';
	break;
	};
	$cekkode= $get_rec->ihik($tabel,$field,NULL,"$sisipan ='".$bulanRomawi."' AND kode='".$kode."'",$field.' DESC',1);
	$row= $cekkode->fetch_array();
	$kode = (int)(substr($row[$field],5,6));
	switch(TRUE){
	case($kode >= 99999):
		$urut = '';
	break;
	case($kode >= 9999):
		$urut = '0';
	break;
	case($kode >= 999):
		$urut = '00';
	break;
	case($kode >= 99):
		$urut = '000';
	break;
	case($kode >= 9):
		$urut = '0000';
	break;
	case($kode >= 0 ):
		$urut = '00000';
	break;
	default:
		$urut = '00000';
	break;
	};
	$hasil = $kodeNota.$urut.''.($kode+1).'/'.$bulanRomawi.'/'.$tahun;
	return $hasil;
	$get_rec->ngecrotsampailemas();
};
function kodeNota($kodeNota,$tabel,$field,$kode,$_user,$_name,$_pass) {
	$get_rec = new ngaceng;
	$get_rec->kukentukamu($_user,$_name,$_pass);
	$tahun = date("Y");
	$bulan = array(1 => "I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII");
	$arx = date("m");
	switch(TRUE){
		case(substr($arx,0,1)==0):
		$ar = substr($arx,1,1);
		break;
		default:
		$ar = $arx;
		break;
	};
	$bulanRomawi = $bulan[$ar];
	$jum = strlen($bulanRomawi);
	switch($jum){
	case'1':
		$sisipan = 'substr('.$field.',16,1)';
	break;
	case'2':
		$sisipan = 'substr('.$field.',16,2)';
	break;
	case'3':
		$sisipan = 'substr('.$field.',16,3)';
	break;
	default:
		$sisipan = 'substr('.$field.',16,4)';
	break;
	};
	$cekkode= $get_rec->ihik($tabel,$field,NULL,"$sisipan ='".$bulanRomawi."' AND kode='".$kode."'",$field.' DESC',1);
	$row= $cekkode->fetch_array();
	$kode = (int)(substr($row[$field],5,9));
	switch(TRUE){
	case($kode >= 99999999):
		$urut = '';
	break;
	case($kode >= 9999999):
		$urut = '0';
	break;
	case($kode >= 999999):
		$urut = '00';
	break;
	case($kode >= 99999):
		$urut = '000';
	break;
	case($kode >= 9999 ):
		$urut = '0000';
	break;
	case($kode >= 999 ):
		$urut = '00000';
	break;
	case($kode >= 99 ):
		$urut = '000000';
	break;
	case($kode >= 9 ):
		$urut = '0000000';
	break;
	case($kode >= 0 ):
		$urut = '00000000';
	break;
	default:
		$urut = '00000000';
	break;
	};
	$hasil = $kodeNota.$urut.''.($kode+1).'/'.$bulanRomawi.'/'.$tahun;
	return $hasil;
	$get_rec->ngecrotsampailemas();
};
function buatnomor($tabel,$field,$kode,$_user,$_name,$_pass){
	$get_rec = new ngaceng;
	$get_rec->kukentukamu($_user,$_name,$_pass);
	$penomoran	= $get_rec->ihik($tabel,$field,NULL,NULL,$field.' DESC');
			$nomor		= $penomoran->fetch_object();
			$exp_nomor	= explode($kode,$nomor->$field);
			$no	= (int)$exp_nomor[1];
			switch(TRUE){
				case($no >= 9999999999999999999):
					$tambah	= '';
				break;
				case($no >= 999999999999999999):
					$tambah	= '0';
				break;
				case($no >= 99999999999999999):
					$tambah	= '00';
				break;
				case($no >= 9999999999999999):
					$tambah	= '000';
				break;
				case($no >= 999999999999999):
					$tambah	= '0000';
				break;
				case($no >= 99999999999999):
					$tambah	= '00000';
				break;
				case($no >= 9999999999999):
					$tambah	= '000000';
				break;
				case($no >= 999999999999):
					$tambah	= '0000000';
				break;
				case($no >= 99999999999):
					$tambah	= '00000000';
				break;
				case($no >= 9999999999):
					$tambah	= '000000000';
				break;
				case($no >= 999999999):
					$tambah	= '0000000000';
				break;
				case($no >= 99999999):
					$tambah	= '00000000000';
				break;
				case($no >= 9999999):
					$tambah	= '000000000000';
				break;
				case($no >= 999999):
					$tambah	= '0000000000000';
				break;
				case($no >= 99999):
					$tambah	= '00000000000000';
				break;
				case($no >= 9999):
					$tambah	= '000000000000000';
				break;
				case($no >= 999):
					$tambah	= '0000000000000000';
				break;
				case($no >= 99):
					$tambah	= '00000000000000000';
				break;
				case($no >= 9):
					$tambah	= '000000000000000000';
				break;
				case($no >= 0):
					$tambah	= '0000000000000000000';
				break;
				default:
					$tambah	= '0000000000000000000';
				break;
				};
				$hasil		= $kode.$tambah.($no+1);
				return $hasil;
	$get_rec->ngecrotsampailemas();
};
?>
