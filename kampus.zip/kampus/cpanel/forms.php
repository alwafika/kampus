<?php if (!defined('AFISYNTAX')) die('No direct script access allowed'); ?>
<?php 
// BELAJAR YANG RAJIN UNTUK MENERJEMAHKAN FUNGSI INI, DAN JANGAN LUPA IHIK TERLEBIH DAHULU, AGAR JASMANI DAN ROHANI ENCER BOS
function startForm($type,$method,$action){
?>
<form class="form-<?php echo $type; ?>" id="AFI-FORM" method="<?php echo $method;?>" action="<?php echo $action;?>" enctype="multipart/form-data">

<?php 
};
function inputText($label,$nama,$value=NULL,$read=NULL){
?>
	<label class="col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">      
		<input type="text" name="<?php echo $nama;?>" id="<?php echo $nama;?>" value="<?php if($value!=NULL){ echo $value;}?>" class="form-control " autocomplete="off" <?php if($read!=NULL){ echo $read;}?>  /> 
 	</div>
<?php	
};
function inputGroup($label,$nama,$value=NULL,$read=NULL){
?>
	<label class="col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="input-group col-sm-12 has-info">      
		<input type="text" name="<?php echo $nama;?>" id="<?php echo $nama;?>" value="<?php if($value!=NULL){ echo $value;}?>" class="form-control " autocomplete="off" <?php if($read!=NULL){ echo $read;}?>  /> 
        <div class="input-group-append">
    		<button class="btn btn-sm btn-outline-info" type="button" id="btn<?php echo $nama;?>" data-toggle="modal" data-target="#myModal"><span class="fa fa-search"></span></button>
  		</div>
 	</div>
<?php	
};
function nominalText($label,$nama,$value=NULL,$read=NULL){
?>
	<label class="col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">      
		<input type="text" name="<?php echo $nama;?>" id="<?php echo $nama;?>" value="<?php if($value!=NULL){ echo $value;}?>" class="form-control " autocomplete="off" <?php if($read!=NULL){ echo $read;}?> onkeydown="return ribu(this, event);" onkeyup="javascript:ribuan(this);"/> 
 	</div>
<?php	
};
function selectText($label,$nama,$value=NULL,$select=NULL){
?>

	<label class="control-label col-sm-12 " for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<select class="form-control " name="<?php echo $nama;?>" id="<?php echo $nama;?>">
        	<option selected disabled  value="">--Silahkan pilih--</option>
        	<?php if($value !=NULL): foreach($value as $isi => $option){?>
       		<option value="<?php echo $isi; ?>" <?php if((isset($select)) && ($select==$isi)){echo"selected";}?>><?php echo $option;?></option>
        	<?php };
			endif;
		  	?> 
		</select>
	</div>
<?php	
};
function selectTexted($label,$nama,$value=NULL,$select=NULL){
?>

	<label class="control-label col-sm-12 " for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<select class="form-control " name="<?php echo $nama;?>" id="<?php echo $nama;?>">
        	<option selected disabled  value="">--Silahkan pilih--</option>
        	<?php if($value !=NULL): foreach($value as $isi){?>
       		<option value="<?php echo $isi; ?>" <?php if((isset($select)) && ($select==$isi)){echo"selected";}?>><?php echo $isi;?></option>
        	<?php };
			endif;
		  	?> 
		</select>
	</div>
<?php	
};

function selectBase($label,$nama,$nameDB,$id_record,$name_record,$value=NULL,$_user,$_name,$_pass,$host,$read=NULL){
	$get_rec = new ngaceng;
	$get_rec->kukentukamu($_user,$_name,$_pass,$host);
	$query=$get_rec->ihik($nameDB,$id_record.",".$name_record);
?>
	<label class="control-label col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<select class="form-control " name="<?php echo $nama;?>" id="<?php echo $nama;?>" <?php if($read!=NULL){ echo $read;}?>>
			<option selected disabled  value="">--Silahkan pilih--</option>
			<?php while($row_query=$query->fetch_assoc()){?>
			<option value="<?php echo $row_query[$id_record]; ?>"<?php if(($value!=NULL) && ($value==$row_query[$id_record])): echo"selected"; else: endif;?>>
			<?php echo $row_query[$name_record];?></option>
          <?php };?> 
		</select>
	</div>
<?php $get_rec->ngecrotsampailemas();
};
function selectWhere($label,$nama,$nameDB,$id_record,$name_record,$where,$value=NULL,$_user,$_name,$_pass,$host,$read=NULL){
	$get_rec = new ngaceng;
	$get_rec->kukentukamu($_user,$_name,$_pass,$host);
	$query=$get_rec->ihik($nameDB,$id_record.",".$name_record,NULL,$where);
?>
	<label class="control-label col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<select class="form-control " name="<?php echo $nama;?>" id="<?php echo $nama;?>" <?php if($read!=NULL){ echo $read;}?>>
			<option selected disabled  value="">--Silahkan pilih--</option>
			<?php while($row_query=$query->fetch_assoc()){?>
			<option value="<?php echo $row_query[$id_record]; ?>"<?php if(($value!=NULL) && ($value==$row_query[$id_record])): echo"selected"; else: endif;?>>
			<?php echo $row_query[$name_record];?></option>
          <?php };?> 
		</select>
	</div>
<?php $get_rec->ngecrotsampailemas();
};
function selectJoinA($label,$nama,$nameDB,$id_record,$name_record,$record_lain,$join,$value=NULL,$_user,$_name,$_pass,$host){
	$get_rec = new ngaceng;
	$get_rec->kukentukamu($_user,$_name,$_pass,$host);
	$query=$get_rec->ihik($nameDB,$id_record.",".$name_record.",".$record_lain,$join);
?>
	<label class="control-label col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<select class="form-control " name="<?php echo $nama;?>" id="<?php echo $nama;?>">
			<option selected disabled  value="">--Silahkan pilih--</option>
			<?php while($row_query=$query->fetch_assoc()){?>
			<option value="<?php echo $row_query[$id_record]; ?>"<?php if(($value!=NULL) && ($value==$row_query[$id_record])): echo"selected"; else: endif;?>>
				<?php echo $row_query[$name_record].' || '.$row_query[$record_lain];?></option>
          <?php };?> 
		</select>
	</div>
<?php $get_rec->ngecrotsampailemas();
};
function selectJoin($label,$nama,$nameDB,$id_record,$name_record,$join,$value=NULL,$_user,$_name,$_pass,$host){
	$get_rec = new ngaceng;
	$get_rec->kukentukamu($_user,$_name,$_pass,$host);
	$query=$get_rec->ihik($nameDB,$id_record.",".$name_record,$join);
?>
	<label class="control-label col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<select class="form-control " name="<?php echo $nama;?>" id="<?php echo $nama;?>">
			<option selected disabled  value="">--Silahkan pilih--</option>
			<?php while($row_query=$query->fetch_assoc()){?>
			<option value="<?php echo $row_query[$id_record]; ?>"<?php if(($value!=NULL) && ($value==$row_query[$id_record])): echo"selected"; else: endif;?>>
			<?php echo $row_query[$name_record];?></option>
          <?php };?> 
		</select>
	</div>
<?php $get_rec->ngecrotsampailemas();
};
function textareaText($label,$nama,$value=NULL,$placehoder=NULL){
?>
	<label class="col-sm-12" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<textarea name="<?php echo $nama;?>" rows="5" class="form-control" id="<?php echo $nama;?>" placeholder="<?php echo $placehoder;?>"><?php echo $value;?></textarea>
	</div>
<?php	
};
function SaveText(){
	?>
	<div class="col-sm-12">
       	<br />
		<div class="text-center">
			<button class="btn btn-outline-primary" type="submit" name="AFI" value="Save">
			<i class="fa fa-save "></i>
                    Simpan
   			</button>
			&nbsp; &nbsp; &nbsp;
			<button class="btn btn-outline-danger" type="reset">
			<i class="fa fa-undo"></i>
                    Reset
			</button>
		</div>
	</div>
    <?php
};
function AddText(){
	?>
	<div class="col-sm-12">
    	<br />
		<div class="text-center">
			<button class="btn btn-outline-primary" type="submit" name="AFI" value="Tambah">
			<i class="fa fa-plus "></i>
                    Tambah
   			</button>
			&nbsp; &nbsp; &nbsp;
			<button class="btn btn-outline-danger" type="reset">
			<i class="fa fa-undo "></i>
                    Reset
			</button>
		</div>
	</div>
    <?php
};
function SaveAll(){
	?>
	<div class="col-sm-12">
    	<br />
		<div class="text-center">
			<button class="btn btn-outline-primary" type="submit" name="AFI" value="Simpan Semua">
			<i class="fa fa-save "></i>
                    Save All
   			</button>
			&nbsp; &nbsp; &nbsp;
			<button class="btn btn-outline-danger" type="submit" name="AFI" value="Batalkan">
			<i class="fa fa-remove"></i>
                    Batalkan
			</button>
		</div>
	</div>
    <?php
};
function updateText(){
	?>
	<div class="col-sm-12">
    	<br />
		<div class="text-center">
			<button class="btn btn-outline-primary" type="submit" name="AFI" value="Update">
			<i class="fa fa-chevron-circle-up "></i>
                    Update
   			</button>
			&nbsp; &nbsp; &nbsp;
			<button class="btn btn-outline-danger" type="reset">
			<i class="fa fa-undo"></i>
                    Reset
			</button>
		</div>
	</div>
    <?php
};
function hiddenText($nama,$value=NULL){?>
<input type="hidden" name="<?php echo $nama;?>" value="<?php echo $value;?>"/>
<?php
};
function textEditor($label,$nama,$value=NULL,$placehoder=NULL){
?>
	<label class="col-sm-12 control-label no-padding-right" for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<textarea name="<?php echo $nama;?>" rows="10" placeholder="<?php echo $placehoder;?>" class="ckeditor form-control" id="<?php echo $nama;?>" ><?php echo $value;?></textarea>
	</div>
<?php	
};
function endForm(){
	echo' 
	</form>';
};
function upfoto($label,$upload,$value=NULL,$read=NULL){
	
?>

<script>
//kenapa fungsion preview menggunakan script?
function preview<?php echo $upload;?>(){var oFReader = new FileReader();oFReader.readAsDataURL(document.getElementById("<?php echo $upload;?>").files[0]);oFReader.onload =function (oFREvent){document.getElementById("upload<?php echo $upload;?>").src = oFREvent.target.result;};};
</script>

            <label class="col-sm-12 control-label "><?php echo $label;?> :</label>
            <div class="col-sm-12 has-info">
            	<img class="kecil" id="upload<?php echo $upload;?>" src="<?php if($value != NULL){ echo $value; }?>" data-toggle="modal" data-target="#myModal" width="40px" height="40px"></img>
                    <input type="file"  name="<?php echo $upload;?>" id="<?php echo $upload;?>" accept="image/png, image/jpeg" value="<?php echo $value;?>" onchange="preview<?php echo $upload;?>()" class="form-control" style="border:none" <?php if($read!=NULL){ echo $read;}?> />
        	</div>
<?php	
};
function upcamera($label,$upload,$value=NULL,$read=NULL){
	
?>
<script>
function preview<?php echo $upload;?>(){var oFReader = new FileReader();oFReader.readAsDataURL(document.getElementById("<?php echo $upload;?>").files[0]);oFReader.onload =function (oFREvent){document.getElementById("upload<?php echo $upload;?>").src = oFREvent.target.result;};};
</script>

            <label class="col-sm-12 control-label "><?php echo $label;?> :</label>
            <div class="col-sm-12 has-info">
            	<img class="kecil" id="upload<?php echo $upload;?>" src="<?php if($value != NULL){ echo $value; }?>" data-toggle="modal" data-target="#myModal" width="40px" height="40px"></img>
                    <input type="file"  name="<?php echo $upload;?>" id="<?php echo $upload;?>" accept="image/png, image/jpeg" capture="camera" value="<?php echo $value;?>" onchange="preview<?php echo $upload;?>()" class="form-control" style="border:none" <?php if($read!=NULL){ echo $read;}?> />
        	</div>
<?php	
};
function upfile($label,$upload,$value=NULL){
?>
            <label class="col-sm-12 control-label"><?php echo $label;?> :</label>
            <div class="col-sm-12 has-info">
                    <input type="file"  name="<?php echo $upload;?>" id="<?php echo $upload;?>" value="<?php echo $value;?>" class="form-control" style="border:none" />
        	</div>
<?php	
};
function selectGob($label,$nama,$select=NULL){
	$value 	= glob('modul/*');
?>

	<label class="control-label col-sm-12 " for="<?php echo $nama;?>"><?php echo $label;?> :</label>
	<div class="col-sm-12 has-info">
		<select class="form-control " name="<?php echo $nama;?>" id="<?php echo $nama;?>">
        	<option selected disabled  value="">--Silahkan pilih--</option>
        	<?php 	foreach($value as $isi){
						switch(TRUE){
							case(is_dir($isi)):?>
       		<option value="<?php echo $isi; ?>" <?php if((isset($select)) && ($select==$isi)){echo"selected";}?>><?php echo $isi;?></option>
        	<?php 
							break;
						};
					};
		  	?> 
		</select>
	</div>
<?php	
};
?>