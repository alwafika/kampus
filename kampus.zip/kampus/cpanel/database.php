<?php if (!defined('AFISYNTAX')) die('Access Denied'); 
// BELAJAR YANG RAJIN UNTUK MENERJEMAHKAN FUNGSI INI, DAN JANGAN LUPA IHIK TERLEBIH DAHULU, AGAR JASMANI DAN ROHANI ENCER BOS
class ngaceng{//fungsi CRUD
	private $conn='';		
	public function kukentukamu($db_user = NULL, $db_name = NULL, $db_pass = NULL, $db_host = NULL){
		$this->conn = new mysqli($db_host,$db_user,$db_pass,$db_name); 
	}//koneksi db
	public function threesome($sql){
		$data = $this->conn->query($sql);
    	return $data;
	}//seluruh data sql di bawah di proses menggunakan $data
	public function ngesex($table,$insert){//memasukan data
		$sql = 'INSERT INTO '.$table.' SET';
		foreach($insert as $field => $value){
			$sql .= ' '.$field.'="'.$this->conn->escape_string($value).'",';
		};
		$sql = rtrim($sql, ',');
		$data = $this->conn->query($sql);
		return $data;
	}
	public function ngentot($table, $where,$update) {//update atau edit data
		$sql = 'UPDATE '.$table.' SET';
		foreach($update as $field => $value){
			$sql .= ' '.$field.'="'.$this->conn->escape_string($value).'",';
		};
		$sql = rtrim($sql, ',');
		$sql .= 'WHERE '.$where.'';
		$data = $this->conn->query($sql);
		return $data;
	}
	public function multingesex($sql){
		$data = $this->conn->multi_query($sql);
    	return $data;
	}
	public function ngecrot($table,$where){//hapus data
		$data = $this->conn->query("DELETE FROM $table WHERE $where");
		return $data;
	}
	public function ihik($table, $rows = '*', $join = NULL, $where = NULL, $order = NULL, $limit = NULL){//join tabel/ tampil
		$sql = 'SELECT '.$rows.' FROM '.$table;
		switch(TRUE){
			case($join != NULL):
				$sql .= ' JOIN '.$join;
			break;
		};
        switch(TRUE){
			case($where != NULL):
				$sql .= ' WHERE '.$where;
			break;
		};
        switch(TRUE){
			case($order != NULL):
				$sql .= ' ORDER BY '.$order;
			break;
		};
        switch(TRUE){
			case($limit != NULL):
				$sql .= ' LIMIT '.$limit;
			break;
        }
		$data = $this->conn->query($sql);
		return $data;
	}
	public function ngecrotsampailemas(){
		$this->conn->close();
	}
}
?>