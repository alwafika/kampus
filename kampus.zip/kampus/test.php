<?php 
$a			= 'saya || makan';
switch(TRUE){
	case substr_count($a,' || ')> '0':
		echo 'Ketemu';
	break;
	default:
		echo 'Tidak Ketemu';
	break;
};

echo '<br>'.substr_count($a," || ");
?>
